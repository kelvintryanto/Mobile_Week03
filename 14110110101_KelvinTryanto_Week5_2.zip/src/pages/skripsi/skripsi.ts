import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { SkripsicheckPage } from '../skripsicheck/skripsicheck';

/**
 * Generated class for the SkripsiPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-skripsi',
  templateUrl: 'skripsi.html',
})
export class SkripsiPage implements OnInit{

  skripsiForm: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SkripsiPage');
  }

  ngOnInit(){
    this.initializeForm();
  }

  private initializeForm(){
    this.skripsiForm = new FormGroup({
      nama: new FormControl(null, Validators.required),
      nim: new FormControl(null, Validators.required),
      judul: new FormControl(null, Validators.required),
      classof: new FormControl(null, Validators.required),
      pembimbingArray: new FormArray([new FormControl(null, Validators.required), new FormControl(null), new FormControl(false)])
    });
  }

  onAddSkripsi(){
    let modal = this.modalCtrl.create(SkripsicheckPage, {skripsiValue: this.skripsiForm.value});
    this.initializeForm();
    // console.log(this.skripsiForm.value);
    modal.present();
  }
}
