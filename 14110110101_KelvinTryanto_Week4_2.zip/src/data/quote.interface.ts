export interface Quote{
    id: string;
    person: string;
    text: string;
}