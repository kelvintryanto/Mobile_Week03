import { Component, OnInit } from '@angular/core';
import { IonicPage, ModalController, NavParams } from 'ionic-angular';
import { Quote } from '../../data/quote.interface';
import { QuotesService } from '../../services/quotes';
import { CheckquotePage } from '../checkquote/checkquote';
import { SettingsService } from '../../services/settings';

/**
 * Generated class for the FavoritePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-favorite',
  templateUrl: 'favorite.html',
})
export class FavoritePage implements OnInit{
  favoriteCollection: any;

  ngOnInit(){
    this.favoriteCollection=this.quotesService.getFavoriteQuotes();
    // console.log(this.favoriteCollection);
  }

  constructor (private quotesService: QuotesService, private modalCtrl: ModalController, public navParams: NavParams, private settingSvc: SettingsService) {

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FavoritePage');
    // console.log(this.quotesService.getFavoriteQuotes());
    // console.log(this.navParams.data);
  }

  onReadQuote(quote: Quote){
    this.quotesService.getFavoriteQuotes();
  }

  onDeleteQuote(quote){
    this.quotesService.removeQuoteFromFavorites(quote);
  }

  onFavoriteClick(favoriteQuote){
    // console.log(favoriteQuote)
    let modal = this.modalCtrl.create(CheckquotePage, {favoriteQuote : favoriteQuote});
    modal.present();
  }
  
  setBgColor(){
    return this.settingSvc.isAltBackground() ? 'hijau' : 'yellow';
  }
}
