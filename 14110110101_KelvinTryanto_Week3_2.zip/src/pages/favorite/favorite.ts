import { Component, OnInit } from '@angular/core';
import { IonicPage, ModalController, NavParams } from 'ionic-angular';
import { Quote } from '../../data/quote.interface';
import { QuotesService } from '../../services/quotes';
import { CheckquotePage } from '../checkquote/checkquote';

/**
 * Generated class for the FavoritePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-favorite',
  templateUrl: 'favorite.html',
})
export class FavoritePage implements OnInit{
  favoriteCollection: any;

  ngOnInit(){
    this.favoriteCollection=this.quotesService.getFavoriteQuotes();
    // console.log(this.favoriteCollection);
  }

  constructor (private quotesService: QuotesService, private modalCtrl: ModalController, public navParams: NavParams) {

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FavoritePage');
    // console.log(this.quotesService.getFavoriteQuotes());
    console.log(this.navParams.data);
  }

  onReadQuote(quote: Quote){
    this.quotesService.getFavoriteQuotes();
  }

  onDeleteQuote(quote,id){
    this.quotesService.removeQuoteFromFavorites(quote,id);
  }

  onFavoriteClick(){
    let modal = this.modalCtrl.create(CheckquotePage);
    modal.present();
  }

}
