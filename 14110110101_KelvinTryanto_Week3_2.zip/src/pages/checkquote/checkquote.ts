import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { text } from '@angular/core/src/render3/instructions';

/**
 * Generated class for the CheckquotePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-checkquote',
  templateUrl: 'checkquote.html',
})
export class CheckquotePage implements OnInit{
  quoteCheck: { id: string, person: string, text: string }

  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl: ViewController) {
  }

  ngOnInit(){
    this.quoteCheck = this.navParams.data;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CheckquotePage');
    console.log("ini quotecheck dikirim dari favorite : " + this.quoteCheck);
  }

  closeModal(){
    this.viewCtrl.dismiss();
  }

}
