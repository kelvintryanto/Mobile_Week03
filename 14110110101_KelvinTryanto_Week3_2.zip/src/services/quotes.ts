import { Quote } from '@angular/compiler';

export class QuotesService {
    private favoriteQuotes: Quote[] = [];

    addQuoteToFavorites(quote: Quote) {
        this.favoriteQuotes.push(quote);
    }

    removeQuoteFromFavorites(quote: Quote, id) {
        var arr = this.favoriteQuotes.indexOf(quote);
        console.log("index is : " + arr) ;
        var removed = this.favoriteQuotes.splice(arr,1);
        return removed;
    }
    getFavoriteQuotes() { return this.favoriteQuotes};
    isFavorite(quote: Quote){
        var arr = this.favoriteQuotes.indexOf(quote);
        console.log(arr);
        if(arr>=0){
            return true;
        }else return false;
    }
}