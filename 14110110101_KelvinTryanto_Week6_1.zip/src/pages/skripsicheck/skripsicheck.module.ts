import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkripsicheckPage } from './skripsicheck';

@NgModule({
  declarations: [
    SkripsicheckPage,
  ],
  imports: [
    IonicPageModule.forChild(SkripsicheckPage),
  ],
})
export class SkripsicheckPageModule {}
