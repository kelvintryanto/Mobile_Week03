import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkripsiPage } from './skripsi';

@NgModule({
  declarations: [
    SkripsiPage,
  ],
  imports: [
    IonicPageModule.forChild(SkripsiPage),
  ],
})
export class SkripsiPageModule {}
